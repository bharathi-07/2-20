<?php
$a=$_POST['fname'];
$b=$_POST['department'];
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("timetable",$conn);
mysql_query("insert into faculty(f_name,department) values('$a','$b')");
header("location:fi.php");
?>
<html>
<head>
<!--<meta http-equiv="refresh" content="0; url=my.php">!-->
</head>
</html>