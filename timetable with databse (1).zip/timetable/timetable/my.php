<html>
<link rel="stylesheet" href="ex.css">
<body align="center">
<h1>TimeTable Generator</h1>

<ul id="nav">
			<li><a href="my.php">Home</a></li>
			<li><a href="demo3.php">TimeTable</a></li>
			<li class="sub"><a href="#">Details</a>
                <ul>
                	<li><a href="ss.php">Subject</a></li>
                	<li><a href="fs.php">Faculty</a></li>
                	
                </ul>
            </li>
			<li class="sub"><a href="#">Insert Data</a>
                <ul>
                	                	<li><a href="isub.php">Subject</a></li>
                	<li><a href="fi.php">Faculty</a></li>
                </ul>
            </li>
			<li><a href="#">Contacts</a></li>
			<li><a href="login.php">Logout</a></li>
		</ul>
<p class="t"></p>
<br>
<br>
<br>
<br>
<br>
<form action="allocation.php" method="post">
<table align="center" cellspacing=1 cellpadding=3 style="margin-top:0px">
<tr align="center"><td colspan=3>
<h2>Enter Your Data Below</h2></td></tr>
<tr>
<td>SUBJECT:
<select id="i" name="n" required="required">
<option></option>
<?php
$conn=mysql_connect("localhost","root","");
if(!$conn){
die(mysql_error());
}
$db=mysql_select_db("timetable",$conn);
$sub=mysql_query("select * from subject");
while($row=mysql_fetch_array($sub))
{
?>
	<option value="<?php echo $row['s_id']?>"><?php echo $row['sub_name'];?>
	</option>
	<?php
}

?>
</td>
</tr>
</select>
<tr>
<td><br>
</td></tr>
<tr>
<td>FACULTY:<select id="id" name="na" required="required">
<option></option><br>
<?php
$sub=mysql_query("select * from faculty");
while($row=mysql_fetch_array($sub))
{
?>
	<option value="<?php echo $row['f_id']?>"><?php echo $row['f_name'];?>
	</option>
	<?php
}

?>
</td>
</tr>
</select>
<tr>
<td><br>
</td></tr>
<tr>
<td>
<input type="submit" value="submit">                         
<input type="reset" value="reset"></td>
</tr>
</table>
</form>
</body>
</html>