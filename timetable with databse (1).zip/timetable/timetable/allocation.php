<?php
$z=$_POST['n'];
$y=$_POST['na'];
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("timetable",$conn);
mysql_query("insert into sub_allocation(s_id, f_id) values($z,$y)");

header("location:my.php");
?>
<html>
<head>
<!--<meta http-equiv="refresh" content="0; url=my.php">!-->
</head>
</html>