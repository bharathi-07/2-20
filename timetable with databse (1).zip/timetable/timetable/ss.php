<html>
<link rel="stylesheet" href="ex.css">
<body align="center">
<h1>TimeTable Generator</h1>
<ul id="nav">
			<li><a href="my.php">Home</a></li>
			<li><a href="demo3.php">TimeTable</a></li>
			<li class="sub"><a href="#">Details</a>
                <ul>
                	                	<li><a href="isub.php">Subject</a></li>
                	<li><a href="fi.php">Faculty</a></li>
                	
                </ul>
            </li>
			<li class="sub"><a href="#">Insert Data</a>
                <ul>
                	                	<li><a href="isub.php">Subject</a></li>
                	<li><a href="fi.php">Faculty</a></li>
                </ul>
            </li>
			<li><a href="#">Contacts</a></li>
			<li><a href="login.php">Logout</a></li>
		</ul>
<p class=" t "></p>
<br>
<br>
<br>
<br>
<br>
<table align="center" border=1 cellspacing=0 cellpadding=7>
<?php
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("timetable",$conn);
$sub=mysql_query("select * from subject");
echo "<tr><th>SUBJECT ID</th><th>SUBJECT NAME</th><th>SUBJECT CODE</th>";
while($row=mysql_fetch_array($sub))
{
echo "<tr><td>".$row['s_id']."</td>"."<td>".$row['sub_name']."</td>"."<td>".$row['sub_code']."</td></tr>";
}
?>
</table>

</body>
</html>
